package com.ejemplo.primerproyecto;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Build;
import android.os.LocaleList;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final String PREFS = "settings";
    private static final String LANGUAGE = "language";
    private static final String[] CODES = {"es", "en", "fr", "de"};

    private static Locale selectedLocale(Context context) {
        String code = context.getSharedPreferences(PREFS, MODE_PRIVATE)
                .getString(LANGUAGE, "es");
        return Locale.forLanguageTag(code);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        Locale locale = selectedLocale(newBase);
        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocales(new LocaleList(locale));
        } else {
            config.locale = locale;
        }
        super.attachBaseContext(newBase.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundResource(com.ejemplo.primerproyecto.R.drawable.fondo_android);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(24), dp(24), dp(24), dp(18));

        TextView title = new TextView(this);
        title.setText(R.string.welcome);
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        content.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.05f));

        Button enter = new Button(this);
        enter.setText(R.string.enter);
        enter.setTextColor(Color.WHITE);
        enter.setTextSize(14);
        enter.setAllCaps(false);
        GradientDrawable outline = new GradientDrawable();
        outline.setColor(Color.TRANSPARENT);
        outline.setStroke(dp(1), Color.WHITE);
        outline.setCornerRadius(dp(2));
        enter.setBackground(outline);
        enter.setMinHeight(dp(42));
        enter.setPadding(dp(28), 0, dp(28), 0);
        enter.setOnClickListener(v ->
                Toast.makeText(this, R.string.welcome_message, Toast.LENGTH_SHORT).show());

        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(42));
        buttonParams.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(enter, buttonParams);

        // Flexible spacer keeps controls clear of the mascot and adapts to orientation.
        View spacer = new View(this);
        content.addView(spacer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.4f));

        Spinner language = new Spinner(this);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.languages, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        language.setAdapter(adapter);
        String current = getSharedPreferences(PREFS, MODE_PRIVATE).getString(LANGUAGE, "es");
        for (int i = 0; i < CODES.length; i++) {
            if (CODES[i].equals(current)) { language.setSelection(i, false); break; }
        }
        language.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            boolean first = true;
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view,
                                                  int position, long id) {
                if (first) { first = false; return; }
                String code = CODES[position];
                String old = getSharedPreferences(PREFS, MODE_PRIVATE)
                        .getString(LANGUAGE, "es");
                if (!code.equals(old)) {
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putString(LANGUAGE, code).apply();
                    recreate();
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        LinearLayout.LayoutParams langParams = new LinearLayout.LayoutParams(
                dp(170), dp(48));
        langParams.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(language, langParams);

        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(content, contentParams);
        setContentView(root);
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
